﻿namespace Models.Models.DBEntities
{
    public class Sedan : Vehicle
    {
        public int NumberOfDoors { get; set; }
    }
}
