﻿namespace Models.Models.DBEntities
{
    public class SUV : Vehicle
    {
        public int NumberOfSeats { get; set; }
    }
}
