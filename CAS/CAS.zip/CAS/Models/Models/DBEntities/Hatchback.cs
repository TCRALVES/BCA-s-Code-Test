﻿namespace Models.Models.DBEntities
{
    public class Hatchback : Vehicle
    {
        public int NumberOfDoors { get; set; }
    }
}
