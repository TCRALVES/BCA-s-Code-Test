﻿namespace Models.Models.DBEntities
{
    public class Truck : Vehicle
    {
        public decimal LoadCapacity { get; set; }
    }
}
