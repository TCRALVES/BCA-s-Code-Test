﻿namespace Models.Models.Enums
{
    public enum VehicleTypeEnum
    {
        HATCHBACK = 0,
        SEDAN = 1,
        SUV = 2,
        TRUCK = 3
    }
}
