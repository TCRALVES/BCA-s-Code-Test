INSERT INTO dbo.VehicleTypes (TypeName)
VALUES ('HATCHBACK')

INSERT INTO dbo.VehicleTypes (TypeName)
VALUES ('SEDAN')

INSERT INTO dbo.VehicleTypes (TypeName)
VALUES ('SUV')

INSERT INTO dbo.VehicleTypes (TypeName)
VALUES ('TRUCK')