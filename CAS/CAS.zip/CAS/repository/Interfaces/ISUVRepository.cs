﻿using Models.Models.DBEntities;

namespace repository.Interfaces
{
    public interface ISUVRepository : IRepository<SUV>
    {
    }
}
